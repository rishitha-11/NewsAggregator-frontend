const API_KEY = import.meta.env.VITE_NEWS_API_KEY; // Add to .env file: VITE_NEWS_API_KEY=0edbfb920e8348019d84eb2e832de091

export const fetchNews = async (category = '') => {
    const url = category
        ? `https://newsapi.org/v2/top-headlines?category=${category}&country=in&apiKey=${API_KEY}`
        : `https://newsapi.org/v2/top-headlines?country=in&apiKey=${API_KEY}`;

    const response = await fetch(url);
    const data = await response.json();
    return data.articles;
};
