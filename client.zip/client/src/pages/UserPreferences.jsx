import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function UserPreferences() {
  const [preferences, setPreferences] = useState({
    age: '',
    interests: [],
    readingTime: '',
    notifications: false,
  });
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  // Available categories for interests
  const categories = [
    'News', 'Technology', 'Entertainment', 'Food', 'Travel', 'Sports',
    'Politics', 'Science', 'Health', 'Business', 'Art', 'Fashion',
  ];

  const updatePreferences = async () => {
    const token = localStorage.getItem("token");
  
    if (!token) {
      setErrorMessage("No token found, user not authenticated.");
      return;
    }
  
    try {
      const response = await axios.put(
        "http://localhost:3006/api/user/preferences",
        {
          age: preferences.age,
          preferences: preferences.interests,
          readingTime: preferences.readingTime,
          notifications: preferences.notifications,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
  
      console.log("Preferences updated:", response.data);
      setSuccessMessage("Preferences saved successfully!");
      setErrorMessage("");
      navigate("/login"); 
    } catch (error) {
      console.error("Error saving preferences:", error.response?.data || error.message);
      setErrorMessage(error.response?.data?.message || "Failed to save preferences.");
      setSuccessMessage("");
    }
  };
  
  

  const handleSubmit = async (e) => {
    e.preventDefault();  
    await updatePreferences();
  };

  const handleInterestChange = (category) => {
    const newInterests = preferences.interests.includes(category)
      ? preferences.interests.filter((i) => i !== category)
      : [...preferences.interests, category];
    setPreferences({ ...preferences, interests: newInterests });
  };

  return (
    <div
      className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8"
      style={{
        backgroundImage: `url(https://images.unsplash.com/photo-1444653614773-995cb1ef9efa?q=80&w=1776&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D)`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      <div className="max-w-3xl mx-auto space-y-8 bg-white p-8 rounded-lg shadow-md bg-opacity-90">
        <div>
          <h2 className="text-center text-3xl font-extrabold text-gray-900">
            Personalize Your Experience
          </h2>
          <p className="mt-2 text-center text-gray-600">
            Help us customize your content feed
          </p>
        </div>

        {successMessage && <p className="text-center text-green-500">{successMessage}</p>}
        {errorMessage && <p className="text-center text-red-500">{errorMessage}</p>}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Age Range */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Age Range</label>
            <select
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-red-500 focus:border-red-500 rounded-md"
              value={preferences.age}
              onChange={(e) => setPreferences({ ...preferences, age: e.target.value })}
            >
              <option value="">Select age range</option>
              <option value="13-17">13-17</option>
              <option value="18-24">18-24</option>
              <option value="25-34">25-34</option>
              <option value="35-44">35-44</option>
              <option value="45+">45+</option>
            </select>
          </div>

          {/* Interests */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              What topics interest you?
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {categories.map((category) => (
                <label key={category} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={preferences.interests.includes(category)}
                    onChange={() => handleInterestChange(category)}
                    className="h-4 w-4 text-red-500 focus:ring-red-500 border-gray-300 rounded"
                  />
                  <span className="text-sm text-gray-700">{category}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Reading Time */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              How much time do you spend reading news daily?
            </label>
            <select
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-red-500 focus:border-red-500 rounded-md"
              value={preferences.readingTime}
              onChange={(e) => setPreferences({ ...preferences, readingTime: e.target.value })}
            >
              <option value="">Select time range</option>
              <option value="less-than-30">Less than 30 minutes</option>
              <option value="30-60">30-60 minutes</option>
              <option value="1-2-hours">1-2 hours</option>
              <option value="more-than-2">More than 2 hours</option>
            </select>
          </div>

          {/* Notifications */}
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={preferences.notifications}
              onChange={(e) => setPreferences({ ...preferences, notifications: e.target.checked })}
              className="h-4 w-4 text-red-500 focus:ring-red-500 border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-700">
              Receive weekly news digest and personalized recommendations
            </label>
          </div>

          {/* Submit Button */}
          <div>
            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-500 hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              Save Preferences
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default UserPreferences;
