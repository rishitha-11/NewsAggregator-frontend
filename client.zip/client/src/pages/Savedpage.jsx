import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { FaBookmark } from "react-icons/fa";
import "../css/Articles.css";

function SavedPage() {
  const [savedArticles, setSavedArticles] = useState([]);
  const navigate = useNavigate();
 
  useEffect(() => {
    const fetchSavedArticles = async () => {
        try {
            const userId = localStorage.getItem("userId"); // Get userId from localStorage
            if (!userId) {
              console.error("❌ No user ID found in localStorage");
              return;
            }
        
            const response = await axios.get(`http://localhost:3006/api/news/saved?userId=${userId}`);
            setSavedArticles(response.data);
        } catch (error) {
            console.error("Error fetching saved articles:", error);
        }
    };

    fetchSavedArticles();
  }, []);

  const handleUnsave = async (articleId) => {
    try {
      const article = savedArticles.find((a) => a.articleId === articleId);

      // Optimistic update
      setSavedArticles((prev) => prev.filter((a) => a.articleId !== articleId));

      await axios.post("http://localhost:3006/api/news/save", {
        userId,
        articleId,
        title: article.title,
        imageUrl: article.imageUrl,
        description: article.description,
        saved: false,
      });
    } catch (error) {
      console.error("❌ Error unsaving article:", error);
    }
  };

  return (
    <div className="articles-page">
      <h2>Saved Articles</h2>
      <div className="articles-grid">
        {savedArticles.length > 0 ? (
          savedArticles.map((article) => (
            <div key={article.articleId} className="article-card">
              <img src={article.imageUrl || "https://via.placeholder.com/300"} alt={article.title} className="article-image" />
              <h3 className="article-title">{article.title}</h3>
              <p className="article-description">{article.description}</p>
              <a href={article.articleId} target="_blank" rel="noopener noreferrer" className="read-more">Read More</a>
              <div className="save-icon" onClick={() => handleUnsave(article.articleId)}>
                <FaBookmark className="text-blue-500 text-xl hover:text-blue-700 cursor-pointer transition-transform hover:scale-110" />
              </div>
            </div>
          ))
        ) : (
          <p>No saved articles yet.</p>
        )}
      </div>
      <button className="back-button" onClick={() => navigate("/profile")}>
        Back to Profile
      </button>
    </div>
  );
}

export default SavedPage;
