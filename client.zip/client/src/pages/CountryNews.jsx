// pages/CountryNews.jsx
import React from 'react';
import { useParams } from 'react-router-dom';
import AllNews from './AllNews';

export default function CountryNewsWrapper() {
  const { country, category } = useParams();

  return (
    <AllNews country={country} category={category} />
  );
}
