import React, { useState, useEffect } from "react";
import LoginNavbar from "../components/LoginNavbar";
import Footer from "../components/footer";
import n1 from "../assets/n1.jpg";
import n2 from "../assets/n2.jpg";
import n3 from "../assets/n3.jpg";
import n4 from "../assets/n4.jpg";
import Navbar from "../components/Navbar";

export default function AboutUs() {
          useEffect(() => {
              // Check if the user is logged in by verifying the presence of a token
              const token = localStorage.getItem('token');
              setIsLoggedIn(!!token); // Set `isLoggedIn` to true if a token exists, otherwise false
          }, []);
      const [user, setUser] = useState({ name: "", email: "", preferences: [] });
      const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
      const [query, setQuery] = useState("news");
      const [isLoggedIn, setIsLoggedIn] = useState(false);
  return (
    <div>
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}

      {/* Hero Section */}
      <section
        style={{
          backgroundColor: "#2D3E50",
          color: "white",
          padding: "50px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div style={{ width: "50%", textAlign: "left" }}>
          <h1 style={{ fontSize: "32px", fontWeight: "bold" }}>
            A Quality Place for Your News
          </h1>
          <p style={{ marginTop: "25px", fontSize: "18px", maxWidth: "80%" }}>
            NEWSVERSE is dedicated to curating and delivering high-quality, reliable news from trusted sources across the globe.
          </p>
        </div>
        <img
          src={n4}
          alt="News Room"
          style={{
            width: "40%",
            borderRadius: "8px",
          }}
        />
      </section>

      {/* Section 1 */}
        <section style={{ display: "flex", alignItems: "center", padding: "50px", backgroundColor: "white" }}>
          <img
            src={n3}
            alt="Journalist"
            style={{
          width: "30%",
          borderRadius: "8px",
            }}
          />
          <div style={{ width: "50%", marginLeft: "30px" }}>
            <h2 style={{ fontSize: "24px", fontWeight: "bold" }}>Reach Passionate Readers</h2>
            <p style={{ marginTop: "10px", color: "#555" }}>
          Expand your reach and engage with audiences interested in the topics you cover. NEWSVERSE provides a platform for meaningful content distribution.
            </p>
            <p style={{ marginTop: "10px", color: "#555" }}>
          Our platform connects you with readers who are eager to discover new perspectives and stories. Join a community of passionate journalists and storytellers today.
            </p>

          </div>
        </section>

        {/* Section 2 */}
          <section style={{ display: "flex", alignItems: "center", padding: "50px", backgroundColor:"#4B5A4E" }}>
            <div style={{ width: "50%", marginRight: "30px" }}>
              <h2 style={{ fontSize: "24px", fontWeight: "bold" , color:"#ffffff"}}>Get Started with NEWSVERSE</h2>
              <p style={{ marginTop: "10px", color: "#ffffff" }}>
            Joining NEWSVERSE is simple. Sign up, share your content, and let your voice be heard in a global news community. Experience the power of a platform designed to amplify your news and connect you with a wider audience.
              </p>
            </div>
            <img
              src={n2}
              alt="News on Mobile"
              style={{
            width: "40%",
            borderRadius: "8px",
              }}
            />
          </section>

          {/* Section 3 */}
            <section style={{ display: "flex", alignItems: "center", padding: "50px", backgroundColor: "white" }}>
              <img
                src={n1}
                alt="Curate Content"
                style={{
              width: "30%",
              borderRadius: "8px",
                }}
              />
              <div style={{ width: "50%", marginLeft: "30px" }}>
                <h2 style={{ fontSize: "24px", fontWeight: "bold" }}>Promote Your News</h2>
                <p style={{ marginTop: "10px", color: "#555" }}>
              Whether you’re a journalist, blogger, or a major publication, NEWSVERSE helps your stories reach the right audience. Leverage our platform to increase your visibility and impact in the news industry.
                </p>
              </div>
            </section>

      <Footer />
    </div>
  );
}
