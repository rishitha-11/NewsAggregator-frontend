import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Card from "../components/Card.jsx"; 
import LoginNavbar from "../components/LoginNavbar.jsx";
import Navbar from "../components/Navbar";

const API_KEY = "f15362a99bce773a087c9bf00cac981d"; // Replace with actual GNews API key

const countryCodeMap = {
  India: "in",
  USA: "us",
  UK: "gb",
  Canada: "ca",
  Australia: "au",
  Germany: "de",
  France: "fr",
  China: "cn",
  Japan: "jp",
  Brazil: "br",
  SouthAfrica: "za",
  Italy: "it",
  Russia: "ru",
};

const languageMap = {
  en: "English",
  hi: "Hindi",
  te: "Telugu",
  ml: "Malayalam",
  ta: "Tamil",
  mr: "Marathi",
};

function CountryName() {
  const { country, category  } = useParams(); 
  const [news, setNews] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
  const [query, setQuery] = useState("news");
  const [language, setLanguage] = useState("en");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const countryCode = countryCodeMap[country] || "in";
  const selectedLanguage = country === "India" ? language : "en";

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
    setNews([]); // Reset on country change
    setPage(1);
    setHasMore(true);
    setError("");
    fetchNews(1); // Initial fetch
  }, [country, language, category]);

  const fetchNews = async (pageNum) => {
    setLoading(true);
    setError("");

    let url = category
  ? `https://gnews.io/api/v4/search?q=${category}&country=${countryCode}&lang=${selectedLanguage}&page=${pageNum}&max=10&token=${API_KEY}`
  : `https://gnews.io/api/v4/top-headlines?country=${countryCode}&lang=${selectedLanguage}&page=${pageNum}&max=10&token=${API_KEY}`;

    console.log(`Fetching Page ${pageNum}:`, url);

    try {
      let response = await axios.get(url);
      let articles = response.data.articles || [];

      // Fallback for non-India countries if no articles in English
      if (articles.length === 0 && country !== "India") {
        const fallbackUrl = `https://gnews.io/api/v4/search?q=${country}&lang=en&page=${pageNum}&max=10&token=${API_KEY}`;
        console.log(`Fallback URL:`, fallbackUrl);
        response = await axios.get(fallbackUrl);
        articles = response.data.articles || [];
      }

      if (articles.length > 0) {
        setNews((prev) => [...prev, ...articles]);
        setPage(pageNum);
      } else {
        setHasMore(false); // No more articles
      }
    } catch (error) {
      console.error("❌ API Error:", error);
      if (error.response) {
        const status = error.response.status;
        console.log("🔴 Error Status:", status);
        if (status === 401) {
          setError("🔐 Invalid or expired API key.");
        } else if (status === 429) {
          setError("⏱️ Too many requests. Please wait before trying again.");
        } else {
          setError("❌ Failed to fetch news. Try again later.");
        }
      } else {
        setError("❌ Network error. Check your connection.");
      }
    } finally {
      setLoading(false);
    }
  };

  const loadMore = () => {
    if (hasMore && !loading) {
      fetchNews(page + 1);
    }
  };

  return (
    <>
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}
      <div className="max-w-6xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">
  {category
    ? ` ${category} in ${country}`
    : `Top News in ${country}`}
</h1>


        {country === "India" && (
          <select 
            onChange={(e) => setLanguage(e.target.value)} 
            value={language} 
            className="p-2 border rounded-md mb-4"
          >
            {Object.entries(languageMap).map(([code, name]) => (
              <option key={code} value={code}>
                {name}
              </option>
            ))}
          </select>
        )}

        {error && <p className="text-red-500 font-semibold">{error}</p>}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {news.map((article, index) => (
            <Card key={index} article={article} />
          ))}
        </div>

        {loading && <p className="mt-4 text-blue-500">Loading news...</p>}

        {!loading && hasMore && (
          <div className="flex justify-center mt-6">
            <button 
              onClick={loadMore}
              className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"
            >
              Load More
            </button>
          </div>
        )}

        {!hasMore && !loading && news.length > 0 && (
          <p className="text-center text-gray-500 mt-4">✅ No more news to show.</p>
        )}
      </div>
    </>
  );
}

export default CountryName;
