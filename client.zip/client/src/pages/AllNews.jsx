import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Card from '../components/Card'; // Assuming you have a reusable Card component
import { useParams } from 'react-router-dom';

const GNEWS_API_KEY = 'f15362a99bce773a087c9bf00cac981d'; // Replace with your GNews API Key
const NEWS_API_KEY = 'b6ec46f9c77f4ba59159353e7b28d53c'; // Replace with your NewsAPI Key

export default function AllNews({ searchQuery }) {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const { country, category } = useParams();

  useEffect(() => {
    const fetchAllNews = async () => {
      setLoading(true);
      try {
        let url;

        // Country-wise and category-wise using GNewsAPI
        if (country && category) {
          url = `https://gnews.io/api/v4/top-headlines?country=${country.toLowerCase()}&topic=${category.toLowerCase()}&lang=en&token=${GNEWS_API_KEY}`;
        } else if (country) {
          url = `https://gnews.io/api/v4/top-headlines?country=${country.toLowerCase()}&lang=en&token=${GNEWS_API_KEY}`;
        } else if (category) {
          url = `https://newsapi.org/v2/top-headlines?topic=${category.toLowerCase()}&lang=en&token=${NEWS_API_KEY}`;
        } else if (searchQuery) {
  
            url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(searchQuery)}&language=en&sortBy=publishedAt&apiKey=${NEWS_API_KEY}&domains=indiatoday.in,ndtv.com`;
        } else {
          // Default: Top headlines using GNews
            url = `https://gnews.io/api/v4/top-headlines?country=in&lang=en&token=${GNEWS_API_KEY}`;
        }

        console.log("Fetching news from:", url);
        const response = await axios.get(url);
        const articles = response.data.articles || [];
        setArticles(articles);
      } catch (error) {
        console.error("Error fetching news:", error);
        setArticles([]);
      }
      setLoading(false);
    };

    fetchAllNews();
  }, [searchQuery, country, category]);

  const getTitle = () => {
    if (country && category) return `${category} in ${country}`;
    if (country) return `Top News in ${country}`;
    if (category) return `Top ${category} News`;
    if (searchQuery === 'news') return 'Top Headlines';
    if (searchQuery) return `Search Results for: "${searchQuery}"`;
    return 'Latest News';
  };

  return (
    <div className="max-w-6xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">{getTitle()}</h1>
      {loading ? (
        <p>Loading articles...</p>
      ) : articles.length === 0 ? (
        <p>No articles found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article, index) => (
            <Card key={index} article={article} />
          ))}
        </div>
      )}
    </div>
  );
}
