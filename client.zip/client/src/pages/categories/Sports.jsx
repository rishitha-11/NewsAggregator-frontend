import React from 'react';
import Navbar from '../../components/Navbar';
function Sports() {
  const articles = [
    {
      id: 1,
      title: "Champions League Highlights",
      image: "https://source.unsplash.com/800x400/?soccer",
      source: "Sports News",
      description: "Latest updates from Champions League matches..."
    },
    {
      id: 2,
      title: "NBA Season Update",
      image: "https://source.unsplash.com/800x400/?basketball",
      source: "Basketball Weekly",
      description: "Current standings and player highlights..."
    },
    {
      id: 3,
      title: "Tennis Grand Slam",
      image: "https://source.unsplash.com/800x400/?tennis",
      source: "Tennis Today",
      description: "Coverage of the latest Grand Slam tournament..."
    }
  ];

  return (
    <>
      <Navbar/>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Sports</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.map((article) => (
            <div key={article.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img
                src={article.image}
                alt={article.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <p className="text-sm text-red-500 font-semibold">{article.source}</p>
                <h2 className="text-xl font-bold mt-2 mb-4">{article.title}</h2>
                <p className="text-gray-600">{article.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Sports;