import React from 'react';

function Technology() {
  const articles = [
    {
      id: 1,
      title: "Latest AI Breakthroughs",
      image: "https://source.unsplash.com/800x400/?artificial-intelligence",
      source: "Tech Review",
      description: "New developments in artificial intelligence..."
    },
    {
      id: 2,
      title: "The Future of Electric Vehicles",
      image: "https://source.unsplash.com/800x400/?electric-car",
      source: "Tech News",
      description: "Electric vehicle innovations and market trends..."
    },
    {
      id: 3,
      title: "5G Revolution",
      image: "https://source.unsplash.com/800x400/?technology",
      source: "Digital Trends",
      description: "How 5G is transforming connectivity..."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Technology</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {articles.map((article) => (
          <div key={article.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <p className="text-sm text-red-500 font-semibold">{article.source}</p>
              <h2 className="text-xl font-bold mt-2 mb-4">{article.title}</h2>
              <p className="text-gray-600">{article.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Technology;