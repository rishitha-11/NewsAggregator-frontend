import React, { useState } from 'react';
import LoginNavbar from "../../components/LoginNavbar";
import AllNews from "../../pages/AllNews"; // Create this component to fetch all news

export default function Dashboard() {
  const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
  const [query, setQuery] = useState("news");
  return (
    <div className="min-h-screen bg-gray-50">
      <LoginNavbar setUserId={setUserId} onSearch={setQuery} />
      <div className="p-4">
        <AllNews userId={userId} searchQuery={query} />
      </div>
    </div>
  );
} 
