function News() {
  const newsArticles = [
    {
      id: 1,
      title: "Global Summit Addresses Climate Change",
      image: "https://source.unsplash.com/800x400/?climate",
      source: "World News",
      description: "World leaders gather to discuss urgent climate action..."
    },
    {
      id: 2,
      title: "Economic Recovery Shows Promising Signs",
      image: "https://source.unsplash.com/800x400/?business",
      source: "Financial Times",
      description: "Markets respond positively to new economic measures..."
    },
    {
      id: 3,
      title: "Breakthrough in Medical Research",
      image: "https://source.unsplash.com/800x400/?medical",
      source: "Health Journal",
      description: "Scientists discover new treatment possibilities..."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Latest News</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {newsArticles.map((article) => (
          <div key={article.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <p className="text-sm text-red-500 font-semibold">{article.source}</p>
              <h2 className="text-xl font-bold mt-2 mb-4">{article.title}</h2>
              <p className="text-gray-600">{article.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default News;