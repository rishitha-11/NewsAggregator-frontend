import React from 'react';

function Entertainment() {
  const articles = [
    {
      id: 1,
      title: "Latest Movie Releases",
      image: "https://source.unsplash.com/800x400/?movie",
      source: "Entertainment Weekly",
      description: "This week's biggest movie premieres..."
    },
    {
      id: 2,
      title: "Music Festival Highlights",
      image: "https://source.unsplash.com/800x400/?concert",
      source: "Music News",
      description: "Recap of the biggest music festivals..."
    },
    {
      id: 3,
      title: "Streaming Shows to Watch",
      image: "https://source.unsplash.com/800x400/?television",
      source: "Streaming Guide",
      description: "Must-watch series on streaming platforms..."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Entertainment</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {articles.map((article) => (
          <div key={article.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <p className="text-sm text-red-500 font-semibold">{article.source}</p>
              <h2 className="text-xl font-bold mt-2 mb-4">{article.title}</h2>
              <p className="text-gray-600">{article.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Entertainment;