import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import axios from 'axios';

export default function SignUp() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [passwordStrength, setPasswordStrength] = useState('Weak');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState(null);
  const [passwordError, setPasswordError] = useState('');
  const navigate = useNavigate();
  const [preferences, setPreferences] = useState([]);
  const [loading, setLoading] = useState(false);

  const validatePassword = (password) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^])[A-Za-z\d@$!%*?&#^]{8,}$/;
    return regex.test(password);
  };

  const handlePasswordChange = (password) => {
    setFormData({ ...formData, password });

    if (password.length > 8 && /[A-Z]/.test(password) && /[0-9]/.test(password)) {
      setPasswordStrength('Strong');
    } else if (password.length > 5) {
      setPasswordStrength('Medium');
    } else {
      setPasswordStrength('Weak');
    }

    if (!validatePassword(password)) {
      setPasswordError(
        'Password must be at least 8 characters long, \ninclude 1 uppercase, 1 lowercase, 1 digit, and 1 special character.'
      );
    } else {
      setPasswordError('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    if (!validatePassword(formData.password)) {
      setPasswordError(
        'Password must be at least 8 characters long, \ninclude 1 uppercase, 1 lowercase, 1 digit, and 1 special character.'
      );
      return;
    }

    const userPreferences = preferences?.length > 0 ? preferences : [];

    setLoading(true);
    try {
      const response = await axios.post("http://localhost:3006/api/user/signup", {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        preferences: userPreferences,
      });

      if (response.status === 201) {
        localStorage.setItem("token", response.data.token);
        navigate("/preferences");
      } else {
        throw new Error(response.data.message || "Signup failed");
      }
    } catch (error) {
      setError(error.response?.data?.message || "Error signing up");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-cover bg-center" style={{ backgroundImage: `url(https://images.unsplash.com/photo-1498644035638-2c3357894b10?q=80&w=1888&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D)` }}>
      <div className="absolute inset-0 bg-black opacity-75"></div>
      <div className="relative bg-white p-8 rounded-lg shadow-md w-120">
        <h2 className="text-2xl font-bold text-center mb-6">Join Newsverse</h2>
        <p className="text-center text-gray-600 mb-6">Stay informed. Stay inspired.</p>

        {error && <p className="text-red-500 text-center">{error}</p>}

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Full name</label>
            <div className="relative">
              <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="text"
                className="w-full pl-10 pr-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-red-500"
                placeholder="Full name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Email address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="email"
                className="w-full pl-10 pr-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-red-500"
                placeholder="Email address"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                className="w-full pl-10 pr-10 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-red-500"
                placeholder="Password"
                value={formData.password}
                onChange={(e) => handlePasswordChange(e.target.value)}
                required
              />
              <button
                type="button"
                className="absolute right-3 top-3 text-gray-400"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
            <p className="text-sm text-gray-600 mt-1">Strength: {passwordStrength}</p>
            {passwordError && (
              <p style={{ color: 'red', whiteSpace: 'pre-line' }}>
                Password must be at least 8 characters,
                include 1 digit, {'\n'} 1 uppercase, 1 lowercase and 1 special character.
              </p>
            )}
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2">Confirm password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                className="w-full pl-10 pr-10 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-red-500"
                placeholder="Confirm password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                required
              />
              <button
                type="button"
                className="absolute right-3 top-3 text-gray-400"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition-colors"
          >
            Continue
          </button>
        </form>

        <div className="text-center text-sm text-gray-600 mt-4">
          <p>
            By continuing, you accept the{' '}
            <a href="/terms" className="text-red-500 hover:underline">
              Terms of Use
            </a>{' '}
            and{' '}
            <a href="/privacy" className="text-red-500 hover:underline">
              Privacy Policy
            </a>
            .
          </p>
          <p className="mt-4">
            Already have an account?{' '}
            <a href="/login" className="text-red-500 hover:underline">
              Log In
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
