import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../css/Articles.css";
import { FaHeart } from "react-icons/fa";

function LikedPage() { 
  const [likedArticles, setLikedArticles] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLikedArticles = async () => {
        try {
          const userId = localStorage.getItem("userId"); // Get userId from localStorage
          if (!userId) {
            console.error("❌ No user ID found in localStorage");
            return;
          }
      
          const response = await axios.get(`http://localhost:3006/api/news/liked?userId=${userId}`);
          setLikedArticles(response.data);
        } catch (error) {
          console.error("Error fetching liked articles:", error);
        }
      };      

    fetchLikedArticles();
  }, []);

  const handleUnlike = async (articleId) => {
    try {
      const userId = localStorage.getItem("userId");
      await axios.delete("http://localhost:3006/api/news/like", {
        data: { userId, articleId },
      });

      // Remove from UI
      setLikedArticles((prev) => prev.filter((article) => article.articleId !== articleId));
    } catch (error) {
      console.error("❌ Error unliking article:", error);
    }
  };

  return (
    <div className="articles-page">
      <h2>Liked Articles</h2>
      <div className="articles-grid">
        {likedArticles.length > 0 ? (
          likedArticles.map((article) => (
            <div key={article.articleId} className="article-card">
              <img src={article.imageUrl || "https://via.placeholder.com/300"} alt={article.title} className="article-image" />
              <h3 className="article-title">{article.title}</h3>
              <p className="article-description">{article.description}</p>
              <a href={article.articleId} target="_blank" rel="noopener noreferrer" className="read-more">Read More</a>
              <FaHeart
                className="like-icon"
                style={{ color: "red", cursor: "pointer", fontSize: "1.5rem", marginTop: "8px" }}
                onClick={() => handleUnlike(article.articleId)}
                title="Unlike this article"
              />
            </div>
          ))
        ) : (
          <p>No liked articles yet.</p>
        )}
      </div>
      <button className="back-button" onClick={() => navigate("/profile")}>
        Back to Profile
      </button>
    </div>
  );
}

export default LikedPage;
