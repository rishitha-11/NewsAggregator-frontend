import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import axios from 'axios';
import news from '../assets/news.jpg';
import tech from '../assets/tech.jpg';
import entertainment from '../assets/entertainment.jpg';
import food from '../assets/food.jpg';
import travel from '../assets/travel.jpg';
import sport from '../assets/sport.jpg';
import n5 from '../assets/n5.avif';
import Footer from '../components/footer';
import health from '../assets/health.avif';
import business from '../assets/business.avif';
import science from '../assets/science.avif';
import fashion from '../assets/fashion.avif';
import politics from '../assets/politics.webp';
import art from '../assets/art.jpg';
import Newsletter from "../components/newsletter";

function Home() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(false);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const searchQuery = searchParams.get('search');
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [trending, setTrending] = useState([]);

  const quotes = [
    '"Journalism is the first rough draft of history."',
    '"News is what somebody does not want you to print. Everything else is advertising."',
    '"Good journalism is good business practice."',
    '"A free press can be good or bad, but, most certainly, without freedom, the press will never be anything but bad."'
  ];

  const categories = [
    { name: 'News', path: '/category/news', image: news, desc: 'Stay informed with global affairs' },
    { name: 'Technology', path: '/category/technology', image: tech, desc: 'Latest tech trends and innovations' },
    { name: 'Entertainment', path: '/category/entertainment', image: entertainment, desc: 'Movies, music, and pop culture' },
    { name: 'Food', path: '/category/food', image: food, desc: 'Delicious recipes and dining guides' },
    { name: 'Travel', path: '/category/travel', image: travel, desc: 'Explore the world’s top destinations' },
    { name: 'Sports', path: '/category/sports', image: sport, desc: 'Live scores and sports news' },
    { name: 'Health', path: '/category/health', image: health, desc: 'Wellness and health tips' },
    { name: 'Business', path: '/category/business', image: business, desc: 'Latest business trends and insights' },
    { name: 'Science', path: '/category/science', image: science, desc: 'Discoveries and innovations in science' },
    { name: 'Fashion',path: '/category/fashion', image: fashion, desc: 'Latest trends in fashion and style' },
    { name: 'Politics',path: '/category/politics', image:politics,desc: 'Political news and analysis' },
    { name: 'Art',path: '/category/art', image: art, desc: 'Art and culture news' }
  ];

  useEffect(() => {
    const fetchTrendingNews = async () => {
      try {
        const API_KEY = 'b6ec46f9c77f4ba59159353e7b28d53c';
        const url = `https://newsapi.org/v2/top-headlines?domains=thehindu.com,indiatoday.in,ndtv.com&apiKey=${API_KEY}&category=general`;
        const response = await axios.get(url);
        setTrending(response.data.articles.slice(2, 20));
      } catch (error) {
        console.error('Error fetching trending news:', error);
      }
    };
    fetchTrendingNews();
    const interval = setInterval(() => {
      setQuoteIndex((prevIndex) => (prevIndex + 1) % quotes.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const fetchNews = async () => {
      if (!searchQuery) return;
      setLoading(true);
      try {
        const API_KEY = 'b6ec46f9c77f4ba59159353e7b28d53c';
        const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(searchQuery)}&language=en&sortBy=publishedAt&apiKey=${API_KEY}`;
        const response = await axios.get(url);
        setArticles(response.data.articles || []);
      } catch (error) {
        console.error('Error fetching news:', error);
        setArticles([]);
      }
      setLoading(false);
    };
    fetchNews();
  }, [searchQuery]);

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      transition={{ duration: 1 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      {!searchQuery && (
        <motion.div 
          initial={{ opacity: 0, y: -50 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 1 }}
          className="text-center mb-20 relative bg-cover bg-center"
          style={{ backgroundImage: `url(${n5})` }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
          <motion.div className="relative z-10 py-16" initial={{ scale: 0.8 }} animate={{ scale: 1 }} transition={{ duration: 0.8 }}>
            <h1 className="text-6xl font-bold mb-4 text-white">INFORMED MINDS</h1>
            <h1 className="text-6xl font-bold mb-8 text-white">INSPIRED LIVES</h1>
            <motion.p className="text-xl text-gray-50 mb-8 italic" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }}>
              {quotes[quoteIndex]}
            </motion.p>
            <motion.div whileHover={{ scale: 1.1 }}>
              <Link to="/signup" className="bg-red-500 text-white px-8 py-3 rounded-md text-lg hover:bg-red-600">
                Sign up
              </Link>
            </motion.div>
          </motion.div>
        </motion.div>
      )}

{searchQuery && (
        <>
          <h1 className="text-3xl font-bold mb-6">
            Results for "{searchQuery}"
          </h1>
          {loading ? (
            <p>Loading articles...</p>
          ) : articles.length === 0 ? (
            <p>No articles found for "{searchQuery}".</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((article, index) => (
                <div
                  key={index}
                  className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <img
                    src={article.urlToImage || news}
                    alt={article.title}
                    className="w-full h-40 object-cover rounded-t-md"
                  />
                  <h3 className="text-lg font-bold mt-4">{article.title}</h3>
                  <p className="text-sm text-gray-600 mt-2">
                    {article.description}
                  </p>
                  <a
                    href={article.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-500 hover:underline mt-4 block"
                  >
                    Read More
                  </a>
                </div>
              ))}
            </div>
          )}
        </>
      )}


{/* Trending Articles Section */}
<div className="my-12">
        <h2 className="text-3xl font-bold text-center mb-6">Trending Now</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trending.map((article, index) => (
            <div key={index} className="bg-white shadow-md p-4 rounded-lg">
              <h3 className="text-lg font-semibold">{article.title}</h3>
              <p className="text-sm text-gray-600 mt-2">{article.description}</p>
              <a href={article.url} target="_blank" rel="noopener noreferrer" className="text-blue-500 mt-2 inline-block">Read more</a>
            </div>
          ))}
        </div>
      </div>

      {!searchQuery && (
        <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <motion.div 
              key={category.name} 
              whileHover={{ scale: 1.05 }} 
              initial={{ opacity: 0, y: 100 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow group"
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Link to={category.path}>
                <motion.img 
                  src={category.image} 
                  alt={category.name} 
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col items-center justify-center transition-opacity duration-300 group-hover:bg-opacity-60">
                  <motion.h3 
                    className="text-white text-2xl font-bold" 
                    initial={{ y: 20, opacity: 0 }} 
                    animate={{ y: 0, opacity: 1 }} 
                    transition={{ duration: 0.5 }}
                  >
                    {category.name}
                  </motion.h3>
                  <motion.p className="text-white text-sm opacity-75 mt-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
                    {category.desc}
                  </motion.p>
                </div>
                <motion.div 
                  className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white text-black px-4 py-2 rounded-full text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                >
                  Explore {category.name}
                </motion.div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      )}
            {/* Newsletter Subscription */}
      <Newsletter />
      <Footer />
    </motion.div>
  );
}

export default Home;


