import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Card from '../components/Card';
import Navbar from '../components/Navbar';
import LoginNavbar from '../components/LoginNavbar';

const GNEWS_API_KEY = 'f15362a99bce773a087c9bf00cac981d';
const NEWS_API_KEY = 'b6ec46f9c77f4ba59159353e7b28d53c';

function CategoryNews() {
    const { category } = useParams();
    const [articles, setArticles] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
    const [query, setQuery] = useState("news");

    // Utility: Convert country name to GNews-compatible code
    const getCountryCode = (countryName) => {
        const map = {
            India: "in",
            USA: "us",
            UK: "gb",
            Canada: "ca",
            Australia: "au",
            Germany: "de",
            France: "fr",
            Italy: "it",
            Japan: "jp",
            China: "cn",
            Brazil: "br",
            Russia: "ru"
        };
        return map[countryName] || "";
    };

    useEffect(() => {
        const updateLoginStatus = () => {
            const token = localStorage.getItem("token");
            setIsLoggedIn(!!token);

            const storedUserId = localStorage.getItem("userId");
            setUserId(storedUserId);
        };

        updateLoginStatus();
        window.addEventListener("storage", updateLoginStatus);

        const fetchNews = async () => {
            setLoading(true);
            try {
                // Clean query for some categories
                let cleanQuery = category;
                if (category === 'food') {
                    cleanQuery = 'food OR cooking OR cuisine';
                } else if (category === 'travel') {
                    cleanQuery = 'travel OR tourism OR destinations';
                } else if (category === 'entertainment') {
                    cleanQuery = 'entertainment OR movies OR music OR celebrities';
                } else if (category === 'technology') {
                    cleanQuery = 'technology OR gadgets OR tech news';
                } else if (category === 'sports') {
                    cleanQuery = 'sports OR football OR cricket OR tennis';
                }

                // Get selected country from localStorage
                const selectedCountry = localStorage.getItem("selectedCountry");
                const countryCode = selectedCountry ? getCountryCode(selectedCountry) : "";

                let url = "";

                if (countryCode) {
                    // ✅ GNews API with country & category query
                    url = `https://gnews.io/api/v4/search?q=${encodeURIComponent(cleanQuery)}&country=${countryCode}&lang=en&max=10&page=1&token=${GNEWS_API_KEY}`;
                } else {
                    // 🌍 NewsAPI fallback
                    url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(cleanQuery)}&language=en&apiKey=${NEWS_API_KEY}`;
                }

                console.log("🔗 Fetching from:", url);
                const response = await fetch(url);
                const data = await response.json();
                const fetchedArticles = data.articles || data.news || [];

                setArticles(Array.isArray(fetchedArticles) ? fetchedArticles : []);
            } catch (error) {
                console.error('❌ Failed to fetch news:', error);
                setArticles([]);
            } finally {
                setLoading(false);
            }
        };

        fetchNews();

        return () => {
            window.removeEventListener("storage", updateLoginStatus);
        };
    }, [category]);

    const getCategoryText = (category) => {
        switch (category) {
            case 'Travel':
                return "Made for you, with stories from #Canada Travel, #U.S. Travel, #Family Travel. Get the latest articles, and news about Travel on NewsVerse.";
            case 'Food':
                return "Explore the world of #Food, #Cooking, and #Cuisine. Get the latest recipes, cooking tips, and food trends on NewsVerse.";
            case 'Entertainment':
                return "Stay updated with the latest in #Entertainment, #Movies, #Music, and #Celebrities. Discover trending stories and news about the entertainment world on NewsVerse.";
            case 'Technology':
                return "Dive into the world of #Technology, #Gadgets, and #Tech News. Stay informed about the latest innovations and trends in the tech industry on NewsVerse.";
            case 'sports':
            case 'Sports':
                return "Catch up on the latest in #Sports, including #Football, #Cricket, and #Tennis. Get breaking news, match updates, and highlights on NewsVerse.";
            case 'Politics':
                return "Stay informed with the latest in #Politics, #Government, and #Elections. Get breaking news, analysis, and opinion on NewsVerse.";
            case 'Science':
                return "Explore the world of #Science, #Research, and #Innovation. Stay informed about the latest discoveries and breakthroughs in science on NewsVerse.";
            case 'Health':
                return "Discover the latest in #Health, #Wellness, and #Fitness. Get tips, news, and advice on living a healthy lifestyle on NewsVerse.";
            case 'Business':
                return "Stay updated with the latest in #Business, #Finance, and #Economy. Get breaking news, analysis, and market updates on NewsVerse.";
            case 'Art':
                return "Explore the world of #Art, #Design, and #Creativity. Discover inspiring stories, art news, and trends on NewsVerse.";
            case 'Fashion':
                return "Stay updated with the latest in #Fashion, #Style, and #Trends. Get fashion tips, news, and updates on NewsVerse.";
            default:
                return "Discover the latest news and articles on NewsVerse. Stay informed with curated stories from around the world.";
        }
    };

    const selectedCountry = localStorage.getItem("selectedCountry");

    return (
        <div className="bg-gray-100 min-h-screen">
            {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}
            <div className="max-w-6xl mx-auto py-8 px-4">
                <h1 className="text-3xl font-bold mb-6">
                    {selectedCountry
                        ? `${category.charAt(0).toUpperCase() + category.slice(1)} in ${selectedCountry} `
                        : `${category.charAt(0).toUpperCase() + category.slice(1)}`}
                </h1>

                <p className="text-gray-600 mb-6">{getCategoryText(category)}</p>

                {loading ? (
                    <p>Loading articles...</p>
                ) : articles.length === 0 ? (
                    <p>No articles found for {category}</p>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {articles.map((article, index) => (
                            <Card
                                key={index}
                                article={article}
                                userId={userId}
                                isLoggedIn={isLoggedIn}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

export default CategoryNews;
