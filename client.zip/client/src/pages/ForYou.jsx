import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from "../components/Card"; // Adjust the path if needed
import LoginNavbar from "../components/LoginNavbar";

const GNEWS_API_KEY = 'f15362a99bce773a087c9bf00cac981d'; // Your GNews API key

export default function ForYou() {
  const [recommendedCategories, setRecommendedCategories] = useState([]);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
  const [query, setQuery] = useState("news");

  useEffect(() => {
    const fetchRecommendations = async () => {
      const userId = localStorage.getItem("userId");
      try {
        const response = await axios.get(`http://localhost:3006/api/recommendations?userId=${userId}`);
        const categories = response.data.recommendedCategories || [];
        setRecommendedCategories(categories);

        const allArticles = [];

        for (let category of categories) {
          const topic = category.toLowerCase();
          try {
            const news = await axios.get(
              `https://gnews.io/api/v4/top-headlines?topic=${topic}&token=${GNEWS_API_KEY}&lang=en&max=11&country=in`
            );
            allArticles.push(...news.data.articles);
          } catch (err) {
            console.error(`Failed to fetch for ${topic}:`, err.response?.data || err.message);
          }
        }

        setArticles(allArticles);
      } catch (error) {
        console.error("Error fetching recommendations:", error);
      }
      setLoading(false);
    };

    fetchRecommendations();
  }, []);

  return (
    <>
    <LoginNavbar setUserId={setUserId} onSearch={setQuery} />
    <div className="max-w-6xl mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Recommended For You</h1>
      {loading ? (
        <p>Loading articles...</p>
      ) : articles.length === 0 ? (
        <p>No recommendations found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article, index) => (
            <Card key={index} article={article} />
          ))}
        </div>
      )}
    </div>
    </>
  );
}
