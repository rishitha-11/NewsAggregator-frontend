import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute'; // New for securing AllNews
import LoginNavbar from './components/LoginNavbar'; 
import Navbar from './components/Navbar'; 
import Home from './pages/Home';
import Login from './pages/Login';
import SignUp from './pages/SignUp';
import UserPreferences from './pages/UserPreferences';
import News from './pages/categories/News';
import Technology from './pages/categories/Technology';
import Entertainment from './pages/categories/Entertainment';
import Food from './pages/categories/Food';
import Travel from './pages/categories/Travel';
import Sports from './pages/categories/Sports';
import Dashboard from './pages/categories/Dashboard';
import Profile from './components/Profile';
import Settings from './components/Settings';
import Privacy from './components/Privacy';
import HelpPage from './components/HelpPage';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from "./pages/ResetPassword";
import Terms from "./components/Terms";
import AboutUs from "./pages/AboutUs";
// New pages you want to add
import AllNews from './pages/AllNews';         // Add this page (from my previous code)
import CategoryNews from './pages/CategoryNews'; // Add this page (from my previous code)
import LikedPage from './pages/Likedpage';
import SavedPage from './pages/Savedpage';
import Publishers from './components/Publishers';
import DoNotSellMyInfo from './components/DoNotSellMyInfo';
import CommunityGuidelines from './components/CommunityGuidelines';
import CountryName from "./pages/CountryName";
import ForYou from "./pages/ForYou";

function App() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Conditional Rendering of Navbars */}
      {location.pathname === '/' ? <Navbar /> : null}
      {/* {location.pathname === '/dashboard' ? <LoginNavbar /> : null} */}
      
      <Routes>
        {/* Existing Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/preferences" element={<UserPreferences />} />
        <Route path="/news" element={<News />} />
        <Route path="/technology" element={<Technology />} />
        <Route path="/entertainment" element={<Entertainment />} />
        <Route path="/food" element={<Food />} />
        <Route path="/travel" element={<Travel />} />
        <Route path="/sports" element={<Sports />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/help" element={<HelpPage />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:token" element={<ResetPassword />} />
        <Route path="/allnews" element={<AllNews />} />
        {/* New Routes for Category & All News */}
        <Route path="/terms" element={<Terms />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/liked" element={<LikedPage />} />
        <Route path="/saved" element={<SavedPage />} />
        <Route path="/publishers" element={<Publishers />} />
        <Route path="/do-not-sell" element={<DoNotSellMyInfo />} />
        <Route path="/category/:category" element={<CategoryNews />} />
        <Route path="/community-guidelines" element={<CommunityGuidelines />} />
        <Route path="/country/:country" element={<CountryName />} />
        <Route path="/country/:country/category/:category" element={<CategoryNews />} />
        <Route path="/foryou" element={<ForYou />} />
        
        
        {/* Protect All News Route */}
        <Route
          path="/all-news" 
          element={
            <ProtectedRoute>
              <AllNews />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

// Wrap the app with AuthProvider to make auth context available globally
export default function Root() {
  return (
    <AuthProvider>
      <Router>
        <App />
      </Router>
    </AuthProvider>
  );
}
