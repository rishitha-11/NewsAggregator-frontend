import React , { useState, useEffect } from 'react';
import LoginNavbar from "./LoginNavbar";
import Footer from './footer';
import axios from "axios";
import Navbar from "../components/Navbar";

export default function Privacy() {
        useEffect(() => {
            // Check if the user is logged in by verifying the presence of a token
            const token = localStorage.getItem('token');
            setIsLoggedIn(!!token); // Set `isLoggedIn` to true if a token exists, otherwise false
        }, []);
    const [user, setUser] = useState({ name: "", email: "", preferences: [] });
    const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
    const [query, setQuery] = useState("news");
    const [isLoggedIn, setIsLoggedIn] = useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}

      {/* Content Section */}
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%', padding: '5px' }}>
        <div style={{ maxWidth: '800px', width: '100%', textAlign: 'left' }}>
          <h1 style={{ textAlign: 'center', marginBottom: '20px', fontSize: '30px' }}>NewsVerse Privacy Policy</h1>
          <div style={{ textAlign: 'justify' }}>
            <p style={{ fontSize: '18px' }}>
              Privacy and data protection are important to the NewsVerse community.
              Transparency is, too. We've done our best to cut through the legal
              jargon and explain in simple terms what information we collect about
              you, what we use it for, and the situations in which we share it with
              others. Please read this privacy policy carefully. It applies to all
              interactions you have with NewsVerse products and services where
              this privacy policy appears or is referenced. This privacy policy does
              not apply to personal information NewsVerse collects from its employees
              and contractors.
            </p>
            <p style={{ fontSize: '18px' }}>
              For purposes of this Privacy Policy, we are a data controller of your
              personal information. You may contact us by email at{' '}
              <a href="mailto:privacy@newsverse.com">privacy@newsverse.com</a> or by
              mail at Legal Department NewsVerse, 555, Bryant Street #352, Palo Alto,
              CA 94301.
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}