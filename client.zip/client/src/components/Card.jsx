// Card.jsx
import React, { useState, useEffect } from "react";
import { FaHeart, FaRegHeart, FaBookmark, FaRegBookmark } from "react-icons/fa";
import axios from "axios";

const Card = ({ article,userId: propUserId  }) => {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userId, setUserId] = useState(localStorage.getItem("userId") || propUserId);

  const articleId = article._id || article.url;
  if (!articleId) {
    console.error("❌ Article data is missing or articleId is undefined:", article);
    return null;
  }

  useEffect(() => {
    const storedUserId = localStorage.getItem("userId");
  
    if (storedUserId) {
      setUserId(storedUserId);
      setIsLoggedIn(true);  // ✅ Mark as logged in only if userId exists
    } else {
      setUserId(null);
      setIsLoggedIn(false); // ✅ Ensure modal appears for non-logged-in users
    }
  
    if (!storedUserId) {
      console.error("❌ No user ID found. User is not logged in.");
      return;
    }
  
    console.log("🔹 Fetching status for user:", storedUserId);
    console.log("🔹 Requesting:", `http://localhost:3006/api/news/status/${storedUserId}`);
  
    const fetchStatus = async () => {
      try {
        const { data } = await axios.get(`http://localhost:3006/api/news/status/${storedUserId}`);
        console.log("✅ Status response:", data);
        setLiked(data.likedArticles.includes(articleId));
        setSaved(data.savedArticles.includes(articleId));
      } catch (error) {
        console.error("❌ Error fetching like/save status:", error?.response?.data || error.message);
      }
    };
  
    fetchStatus();
  }, [propUserId, articleId]);
  


  const handleLike = async () => {
    if (!isLoggedIn || !userId) {   // 🚨 Strict check for login status
      setShowAuthModal(true);
      return;
    }
  
    const newLiked = !liked;
    setLiked(newLiked);
  
    try {
      console.log("🔹 Sending like request:", { userId, articleId, liked: newLiked });
  
      await axios.post("http://localhost:3006/api/news/like", {
        userId,
        articleId,
        title: article.title,
        imageUrl: article.urlToImage,
        description: article.description,
        liked: newLiked,
      });
    } catch (error) {
      console.error("❌ Error liking article:", error);
      setLiked(!newLiked);
    }
  };
  const handleSave = async () => {
    if (!isLoggedIn || !userId) {   // 🚨 Strict check for login status
      setShowAuthModal(true);
      return;
    }
  
    const newSaved = !saved;
    setSaved(newSaved);
  
    try {
      console.log("🔹 Sending save request:", { userId, articleId, saved: newSaved });
  
      await axios.post("http://localhost:3006/api/news/save", {
        userId,
        articleId,
        title: article.title,
        imageUrl: article.urlToImage,
        description: article.description,
        saved: newSaved,
      });
    } catch (error) {
      console.error("❌ Error saving article:", error);
      setSaved(!newSaved);
    }
  };
    
  

  return (
    <div className="border border-gray-300 rounded-lg shadow-md overflow-hidden w-full m-5 bg-white flex flex-col justify-between">
      <img
  src={article.urlToImage || article.image || 'https://via.placeholder.com/300'}
  alt={article.title}
  className="w-full h-44 object-cover"
  onError={(e) => e.target.src = "https://via.placeholder.com/300"} 
/>

      <div className="p-4 flex flex-col flex-grow">
        <div className="text-sm text-gray-1000">
          {new Date(article.publishedAt).toLocaleDateString()}
        </div>
        <h3 className="text-lg font-semibold mb-2">{article.title}</h3>
        <p className="text-sm text-gray-600 mb-3 flex-grow">{article.description}</p>
        <a
          href={article.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-500 mt-2 inline-block"
        >
          Read more
        </a>
        <div className="mt-4 text-sm text-gray-1000">Source: {article.source.name}</div>
      </div>
      <div className="p-4 flex justify-between items-center">
        <span onClick={handleLike} className="text-xl cursor-pointer">
          {liked ? <FaHeart className="text-red-500" /> : <FaRegHeart />}
        </span>
        <span onClick={handleSave} className="text-xl cursor-pointer">
          {saved ? <FaBookmark className="text-blue-500" /> : <FaRegBookmark />}
        </span>
      </div>
      {showAuthModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-60 backdrop-blur-sm">
          <div className="bg-white p-6 rounded-lg shadow-xl transform transition-all scale-100 animate-fade-in max-w-sm w-full">
            <p className="text-lg font-semibold text-gray-900 mb-4 text-center">
              To like or save news articles and <br /> get personalized news, please <br /> log in or sign up first.
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={() => (window.location.href = '/login')}
                className="bg-red-500 text-white px-5 py-2 rounded-lg hover:bg-red-600 transition shadow-md"
              >
                Login
              </button>
              <button
                onClick={() => (window.location.href = '/signup')}
                className="bg-red-500 text-white px-5 py-2 rounded-lg hover:bg-red-600 transition shadow-md"
              >
                Sign Up
              </button>
            </div>
            <button
              onClick={() => setShowAuthModal(false)}
              className="mt-4 block w-full text-center text-gray-500 hover:text-gray-700 hover:underline"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Card;
