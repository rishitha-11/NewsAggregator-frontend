import React, { useState, useEffect } from "react";
import Navbar from "./Navbar";
import LoginNavbar from "./LoginNavbar";  // ✅ Navbar with login features
import Footer from "./footer";

export default function Publishers() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState({ name: "", email: "", preferences: [] });
  const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
  const [query, setQuery] = useState("news");

  useEffect(() => {
    // ✅ Check if user is logged in (by verifying token)
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token); // ✅ If token exists, user is logged in
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}

      {/* Content Section */}
      <div style={{ flex: 1, display: "flex", justifyContent: "center", alignItems: "center", width: "100%", padding: "5px" }}>
        <div style={{ maxWidth: "800px", width: "100%", textAlign: "left" }}>
          <h1 style={{ textAlign: "center", marginBottom: "20px", fontSize: "30px" }}>For Publishers</h1>
          <div style={{ textAlign: "justify" }}>
            <p style={{ fontSize: "18px" }}>
              Welcome to NewsVerse Publishers Hub. If you are a content creator, journalist, or media company,
              you can distribute your articles and reach a larger audience through our platform.
            </p>

            <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Why Publish on NewsVerse?</h2>
            <ul style={{ fontSize: "18px", marginLeft: "20px" }}>
              <li>1. Expand your audience and gain more visibility.</li>
              <li>2. Monetize your content through our partnership program.</li>
              <li>3. Get insights into reader engagement and analytics.</li>
              <li>4. Protect your content with our security measures.</li>
            </ul>

            <h2 style={{ fontSize: "22px", marginTop: "20px" }}>How to Get Started</h2>
            <p style={{ fontSize: "18px" }}>To become a NewsVerse publisher, follow these steps:</p>
            <ul style={{ fontSize: "18px", marginLeft: "20px" }}>
              <li>1. Register as a publisher on our platform.</li>
              <li>2. Submit your content for review.</li>
              <li>3. Once approved, publish articles directly to NewsVerse.</li>
              <li>4. Track performance using our analytics tools.</li>
            </ul>

            <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Content Guidelines</h2>
            <p style={{ fontSize: "18px" }}>To maintain quality and credibility, we require publishers to adhere to our content guidelines:</p>
            <ul style={{ fontSize: "18px", marginLeft: "20px" }}>
              <li>✔ Provide accurate and verified news.</li>
              <li>✔ Avoid misleading or clickbait headlines.</li>
              <li>✔ Ensure original and plagiarism-free content.</li>
              <li>✔ Respect user privacy and ethical journalism standards.</li>
            </ul>

            <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Join Us</h2>
            <p style={{ fontSize: "18px" }}>
              Ready to become a NewsVerse publisher? Get started today by registering <a href="/register">here</a>.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
