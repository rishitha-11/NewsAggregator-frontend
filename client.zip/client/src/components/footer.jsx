import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <div>
    <footer className="mt-16 bg-gray-100 py-8 text-center text-gray-600 text-sm">
      <div className="flex flex-wrap justify-center space-x-4 mb-4">
        <Link to="/about" className="hover:underline">
          About Us
        </Link>
        <Link to="/publishers" className="hover:underline">
          Publishers
        </Link>
        <Link to="/help" className="hover:underline">
          Help
        </Link>
        <Link to="/terms" className="hover:underline">
          Terms
        </Link>
        <Link to="/privacy" className="hover:underline">
          Privacy Policy
        </Link>
        <Link to="/do-not-sell" className="hover:underline">
          Do Not Sell My Info
        </Link>
        <Link to="/community-guidelines" className="hover:underline">
          Community guidelines
        </Link>
      </div>
      <p>© 2025 NewsVerse</p>
      </footer>
    </div>
  );
}