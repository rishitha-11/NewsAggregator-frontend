import React, { useState } from "react";
import axios from "axios";

const Newsletter = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubscribe = async (e) => {
    e.preventDefault();
    setMessage('');

    try {
      const response = await axios.post('http://localhost:3006/api/newsletter/subscribe', { email });
      setMessage(response.data.message);
    } catch (error) {
      setMessage(error.response?.data?.message || 'Subscription failed. Try again.');
    }
  };
  

  return (
    <div className="p-6 bg-gray-100 rounded-lg text-center">
      <h3 className="text-2xl font-bold mb-4">Subscribe to Our Newsletter</h3>
      <form onSubmit={handleSubscribe} className="flex flex-col md:flex-row gap-3 justify-center">
        <input 
          type="email" 
          placeholder="Enter your email" 
          className="p-2 border rounded-md" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          required
        />
        <button type="submit" className="bg-red-500 text-white px-6 py-2 rounded-md hover:bg-red-600">
          Subscribe
        </button>
      </form>
      {message && <p className="text-sm mt-3 text-gray-700">{message}</p>}
    </div>
  );
};

export default Newsletter;
