import React , { useState, useEffect }from 'react';
import LoginNavbar from "./LoginNavbar";
import Footer from './footer';
import axios from "axios";
import Navbar from "./Navbar";

export default function Terms() {
          useEffect(() => {
              // Check if the user is logged in by verifying the presence of a token
              const token = localStorage.getItem('token');
              setIsLoggedIn(!!token); // Set `isLoggedIn` to true if a token exists, otherwise false
          }, []);
      const [user, setUser] = useState({ name: "", email: "", preferences: [] });
      const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
      const [query, setQuery] = useState("news");
      const [isLoggedIn, setIsLoggedIn] = useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}

      {/* Content Section */}
      <div style={{ flex: 1, width: '100%', maxWidth: '900px', margin: 'auto', padding: '20px', textAlign: 'left' }}>
        <h1 style={{ textAlign: 'center', fontSize: '30px' }}>NewsVerse Terms of Service</h1>
        <p style={{ textAlign: 'center', fontSize: '18px', marginBottom: '20px' }}>Updated March 25, 2025</p>

        <h2 style={{ fontSize: '22px' }}>Welcome to NewsVerse</h2>
        <p>These Terms of Service ("Terms") govern your use of NewsVerse, including its website, services, and any content available through it. By accessing or using our platform, you agree to comply with and be bound by these Terms. If you do not agree, please do not use NewsVerse.</p>

        <h2 style={{ fontSize: '22px' }}>User Responsibilities</h2>
        <p>You agree to use NewsVerse in accordance with all applicable laws and regulations. You must not engage in activities that:</p>
        <ul style={{ paddingLeft: '20px' }}>
          <li>Violate intellectual property rights.</li>
          <li>Spread false or misleading information.</li>
          <li>Harm or exploit others, including harassment and hate speech.</li>
          <li>Introduce malware, hacking, or unauthorized access to systems.</li>
        </ul>

        <h2 style={{ fontSize: '22px' }}>Content Ownership</h2>
        <p>All content available on NewsVerse, including text, graphics, logos, and images, is the property of NewsVerse or its content providers and is protected by intellectual property laws. You may not copy, modify, distribute, or sell any content without prior permission.</p>

        <h2 style={{ fontSize: '22px' }}>Privacy Policy</h2>
        <p>Your privacy is important to us. Our <a href="/privacy">Privacy Policy</a> explains how we collect, use, and share your personal data. By using NewsVerse, you acknowledge that you have read and agreed to our Privacy Policy.</p>

        <h2 style={{ fontSize: '22px' }}>Account Termination</h2>
        <p>We reserve the right to suspend or terminate your account if you violate these Terms or engage in harmful activities. If your account is terminated, you may lose access to your data and content.</p>

        <h2 style={{ fontSize: '22px' }}>Limitation of Liability</h2>
        <p>NewsVerse is provided "as is" without warranties of any kind. We are not responsible for any damages, including loss of data or business interruptions, arising from your use of NewsVerse.</p>

        <h2 style={{ fontSize: '22px' }}>Changes to These Terms</h2>
        <p>We may update these Terms from time to time. If there are significant changes, we will notify users through appropriate means. Your continued use of NewsVerse after changes are made constitutes acceptance of the new Terms.</p>

        <h2 style={{ fontSize: '22px' }}>Contact Us</h2>
        <p>If you have any questions about these Terms, please contact us at <a href="mailto:support@newsverse.com">support@newsverse.com</a>.</p>
      </div>

      <Footer />
    </div>
  );
}
