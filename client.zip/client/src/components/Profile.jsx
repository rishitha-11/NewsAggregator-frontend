import React, { useState, useEffect } from "react";
import axios from "axios";
import { User, Mail } from "lucide-react";
import { useNavigate } from "react-router-dom";
import LoginNavbar from "./LoginNavbar";
import "../css/Profile.css";
import { FaEnvelope, FaUserCircle, FaArrowRight } from "react-icons/fa";
import Footer from './footer';
import Navbar from "./Navbar";

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState({ name: "", email: "", preferences: [] });
  const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
  const [query, setQuery] = useState("news");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) return;

        const response = await axios.get("http://localhost:3006/api/user/profile", {
          headers: { Authorization: `Bearer ${token}` },
        });

        setUser({
          name: response.data.name,
          email: response.data.email,
          preferences: response.data.preferences || [],
        });
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    };

    fetchUserData();
  }, []);

  return (
    <div className="bg-gray min-h-screen">
      {/* Navbar */}
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}

      {/* Profile Card Container */}
      <div className="flex justify-center items-center mt-20">
        <div className="bg-white shadow-lg rounded-lg p-6 w-96 text-center transform transition-all hover:scale-80">
          {/* User Icon */}
          <div className="flex justify-center">
            <User className="h-16 w-16 text-gray-500" />
          </div>

          {/* User Name */}
          <h2 className="text-xl font-bold mt-3">{user.name}</h2>
          <p className="text-gray-500">@{user.name.toLowerCase()}</p>

          {/* Email */}
          <div className="flex items-center bg-gray-100 rounded-full px-3 py-2 mt-4 shadow-md">
            <Mail className="h-5 w-5 text-gray-600" />
            <span className="ml-2 text-gray-700">{user.email}</span>
          </div>

          {/* Preferences Section */}
          <h3 className="text-lg font-semibold mt-5">Preferences</h3>
          <div className="grid grid-cols-2 gap-2 mt-3">
            {user.preferences.length > 0 ? (
              user.preferences.map((pref, index) => (
                <span key={index} className="bg-gray-200 px-3 py-2 rounded-lg text-gray-700 text-sm font-medium shadow-sm">
                  {pref}
                </span>
              ))
            ) : (
              <span className="text-gray-500 col-span-2">No Preferences Set</span>
            )}
          </div>
          <div className="profile-links">
                      <div className="profile-link-item" onClick={() => navigate("/liked")}>
                        <span>Liked</span>
                        <FaArrowRight className="arrow-icon" />
                      </div>
          
                      <div className="profile-link-item" onClick={() => navigate("/saved")}>
                        <span>Saved</span>
                        <FaArrowRight className="arrow-icon" />
                      </div>
                    </div> 
        </div>
      </div>
          < Footer/>
    </div>
  );
}
