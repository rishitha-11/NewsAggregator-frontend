import React, { useState, useEffect } from 'react';
import LoginNavbar from "./LoginNavbar";
import '../css/HelpPage.css';
import Footer from './footer';
import Navbar from './Navbar';

export default function HelpPage() {
        useEffect(() => {
            // Check if the user is logged in by verifying the presence of a token
            const token = localStorage.getItem('token');
            setIsLoggedIn(!!token); // Set `isLoggedIn` to true if a token exists, otherwise false
        }, []);
    const [user, setUser] = useState({ name: "", email: "", preferences: [] });
    const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
    const [query, setQuery] = useState("news");
    const [isLoggedIn, setIsLoggedIn] = useState(false);
  return (
    <div className="min-h-screen bg-gray-50">
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}
        <div className="help-container">
      <header className="help-header">
        <h1>Help & Support</h1>
        <p>Welcome to our Help Center. Let us assist you in finding the answers you're looking for.</p>
      </header>

      {/* Frequently Asked Questions Section */}
      <section className="faq-section">
        <h2 className="section-heading">Frequently Asked Questions</h2>
        <div className="faq-item">
          <h3>How do I create an account?</h3>
          <p>
            To create an account, simply click on the "Sign Up" button at the top of the page, enter your details, and follow the instructions.
          </p>
        </div>
        <div className="faq-item">
          <h3>How do I reset my password?</h3>
          <p>
            If you've forgotten your password, click on the "Forgot Password" link on the login page, and follow the steps to reset your password.
          </p>
        </div>
        <div className="faq-item">
          <h3>How can I contact customer support?</h3>
          <p>
            You can contact our customer support team by emailing us at <a href="mailto:support@newsverse.com">support@newsverse.com</a>.
          </p>
        </div>
      </section>

      {/* Troubleshooting Section */}
      <section className="troubleshooting-section">
        <h2 className="section-heading">Troubleshooting</h2>
        <p>If you're experiencing issues with our website, try the following:</p>
        <ul>
          <li>Clear your browser's cache and cookies.</li>
          <li>Ensure your internet connection is stable.</li>
          <li>Try using a different browser or device.</li>
        </ul>
      </section>

      {/* Contact Information Section */}
      <section className="contact-section">
        <h2 className="section-heading">Contact Us</h2>
        <p>If you have further questions or need assistance, feel free to reach out:</p>
        <ul>
          <li>Email: <a href="mailto:support@newsverse.com">support@newsverse.com</a></li>
          <li>Phone: 9876543210</li>
        </ul>
      </section>
    </div>
    < Footer/>
    </div>

  );
}
