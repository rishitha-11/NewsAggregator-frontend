import React, { useState, useEffect } from "react";
import Navbar from "./Navbar";
import LoginNavbar from "./LoginNavbar";  // ✅ Navbar with login features
import Footer from "./footer";

export default function CommunityGuidelines() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState({ name: "", email: "", preferences: [] });
  const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
  const [query, setQuery] = useState("news");

  useEffect(() => {
    // ✅ Check if user is logged in (by verifying token)
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token); // ✅ If token exists, user is logged in
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}

      {/* Content Section */}
      <div style={{ flex: 1, maxWidth: "800px", margin: "0 auto", padding: "20px" }}>
        <h1 style={{ textAlign: "center", fontSize: "30px", marginBottom: "20px" }}>Community Guidelines</h1>

        <p style={{ fontSize: "18px", textAlign: "justify" }}>
          Welcome to NewsVerse! We believe in creating a respectful and inclusive community. These guidelines ensure
          a safe and productive environment for all users.
        </p>

        <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Respectful Communication</h2>
        <ul style={{ fontSize: "18px", marginLeft: "20px" }}>
          <li>✔ Be kind and respectful in discussions.</li>
          <li>✔ No hate speech, harassment, or threats.</li>
          <li>✔ Constructive criticism is encouraged, but personal attacks are not.</li>
        </ul>

        <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Content Guidelines</h2>
        <ul style={{ fontSize: "18px", marginLeft: "20px" }}>
          <li>✔ Share accurate and fact-based content.</li>
          <li>✔ No misleading, false, or inflammatory information.</li>
          <li>✔ Respect copyright and do not post plagiarized content.</li>
        </ul>

        <h2 style={{ fontSize: "22px", marginTop: "20px" }}>User Safety</h2>
        <ul style={{ fontSize: "18px", marginLeft: "20px" }}>
          <li>✔ Do not share personal information publicly.</li>
          <li>✔ Report suspicious activity or abusive behavior.</li>
          <li>✔ Follow platform-specific safety policies.</li>
        </ul>

        <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Enforcement</h2>
        <p style={{ fontSize: "18px" }}>
          Violating these guidelines may result in content removal, account suspension, or permanent ban. We encourage
          everyone to engage positively and help maintain a safe community.
        </p>

        <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Contact Us</h2>
        <p style={{ fontSize: "18px" }}>
          If you have any concerns or questions regarding our community guidelines, please reach out to us at  
          <a href="/help" style={{ color: "blue", textDecoration: "underline" }}> Contact Support</a>.
        </p>
      </div>

      <Footer />
    </div>
  );
}
