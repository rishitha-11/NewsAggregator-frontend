import React, { useState } from 'react';
import LoginNavbar from "./LoginNavbar";
import '../css/Settings.css';
import { FaUserCircle } from "react-icons/fa";

function Settings() {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [bio, setBio] = useState('');
  const [avatar, setAvatar] = useState(null);
  const [isPrivateProfile, setIsPrivateProfile] = useState(false);

  const handleNameChange = (event) => setName(event.target.value);
  const handleUsernameChange = (event) => setUsername(event.target.value);
  const handleEmailChange = (event) => setEmail(event.target.value);
  const handleBioChange = (event) => setBio(event.target.value);
  const handleAvatarChange = (event) => { setAvatar(event.target.files[0]); };
  const handlePrivateProfileChange = () => { setIsPrivateProfile(!isPrivateProfile); };

  return (
    <div className='settings-page'>
    <LoginNavbar />
    <div className="settings-container">
      <div className="profile-section">
        <div className="profile-image">
          <FaUserCircle size={64} />
        </div>
        <div><h2 className="profile-name">JAYA SRI</h2></div>
      </div>
      <div>
      <ul className="settings-nav">
          <li>Profile settings</li>
          <li>Email subscriptions</li>
          <li>Content options</li>
          <li>Federation settings</li>
        </ul>
      </div>
      <form className="form-container">
        <div className="form-field">
          <label htmlFor="name">Name:</label>
          <input 
            type="text" 
            id="name" 
            value={name} 
            onChange={handleNameChange} 
            placeholder="Enter your name" 
          />
        </div>
        <div className="form-field">
          <label htmlFor="username">Username:</label>
          <input 
            type="text" 
            id="username" 
            value={username} 
            onChange={handleUsernameChange} 
            placeholder="Enter your username" 
          />
        </div>
        <div className="form-field">
          <label htmlFor="email">Email:</label>
          <input 
            type="email" 
            id="email" 
            value={email} 
            onChange={handleEmailChange} 
            placeholder="Enter your email" 
          />
        </div>
        <div className="form-field">
          <label htmlFor="bio">Bio:</label>
          <textarea 
            id="bio" 
            value={bio} 
            onChange={handleBioChange} 
            placeholder="Tell us about yourself"
          />
        </div>
        {/* Private Profile Section */}
        <div className="private-profile">
        <div className="checkbox-container">
          <input
            type="checkbox"
            id="private-profile"
            checked={isPrivateProfile}
            onChange={handlePrivateProfileChange}
          />
          <label>Private Profile</label>
        </div>
        <p className="description">
          Control who can view or follow your profile or your magazines.
        </p>
      </div>
      {/* Avatar Upload Section */}
      <div className="avatar-upload">
        <label htmlFor="avatar" className="upload-label">Avatar</label>
        <input
          type="file"
          id="avatar"
          onChange={handleAvatarChange}
          className="avatar-input"
        />
        {avatar && (
          <p className="file-info">Selected file: {avatar.name}</p>
        )}
      </div>

      {/* Account Settings Section */}
      <div className="account-settings">
        <h3>Account Settings</h3>
        <ul>
          <li>Your Privacy Choices</li>
          <li>Change Password</li>
          <li>Delete Account</li>
        </ul>
      </div>
        <button className="save-button" type="submit">
          Save Changes
        </button>
      </form>
    </div>
    </div>
  );
}

export default Settings;
