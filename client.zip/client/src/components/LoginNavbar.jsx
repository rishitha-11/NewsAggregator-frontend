import React, { useState, useEffect, useRef } from "react";
import { User, Plus } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { FaSearch } from "react-icons/fa";
import axios from "axios";

export default function LoginNavbar({ onSearch, setUserId }) {
  const [user, setUser] = useState(null);
  const [searchInput, setSearchInput] = useState("");
  const [isPreferencesMenuOpen, setIsPreferencesMenuOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false); // false = Add, true = Remove
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [preferences, setPreferences] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState('');
  const [allPreferences, setAllPreferences] = useState([
    "Technology",
    "Health",
    "Science",
    "Business",
    "Entertainment",
    "Sports",
    "Politics",
    "Travel",
    "Food",
    "Fashion",
    "Art",
    "News",

  ]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchUserProfile();
  
    const storedCountry = localStorage.getItem("selectedCountry");
    if (storedCountry) {
      setSelectedCountry(storedCountry);
    }
  }, []);
  

  const fetchUserProfile = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const response = await axios.get("http://localhost:3006/api/user/profile", {
        headers: { Authorization: `Bearer ${token}` },
      });

      setUser(response.data);
      setUserId(response.data._id);
      localStorage.setItem("userId", response.data._id);
      setUsername(response.data.name);
      setPreferences(response.data.preferences || []);
    } catch (error) {
      console.error("Error fetching user profile:", error);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput);
    }
  };

  const handleCountryChange = (e) => {
    const country = e.target.value;
  
    if (!country) {
      // If user selects "Select Country" (i.e., empty value)
      localStorage.removeItem("selectedCountry");
      setSelectedCountry('');
      navigate("/dashboard"); // Navigate to dashboard or homepage for international news
    } else {
      setSelectedCountry(country);
      localStorage.setItem("selectedCountry", country);
      navigate(`/country/${country}`);
    }
  };
  
  

  const handleRemovePreference = async (category, event) => {
    event.stopPropagation();
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const updatedPreferences = preferences.filter((pref) => pref !== category);

      await axios.put(
        "http://localhost:3006/api/user/preferences",
        { preferences: updatedPreferences },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setPreferences(updatedPreferences);
    } catch (error) {
      console.error("Error removing preference:", error);
    }
  };

  const handleAddPreference = async (category, event) => {
    event.stopPropagation();
    if (preferences.includes(category)) return;

    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const updatedPreferences = [...preferences, category];

      await axios.put(
        "http://localhost:3006/api/user/preferences",
        { preferences: updatedPreferences },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setPreferences(updatedPreferences);
    } catch (error) {
      console.error("Error adding preference:", error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("selectedCountry");
    alert("Logged out successfully!");
    navigate("/login");
  };

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
      
      <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold text-red-500">
              NewsVerse
            </Link>
          </div>

          <div className="flex-1 flex justify-center px-4">
            <form onSubmit={handleSearch} className="max-w-lg w-full">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <FaSearch className="text-gray-400" />
                </div>
                <input
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:border-red-500"
                  placeholder="Search NewsVerse"
                  type="search"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                />
              </div>
            </form>
          </div>

          {/* Country Selector, Login/Signup Links */}
          <div className="flex items-center space-x-6">
            {/* Country Dropdown */}
            <select
              value={selectedCountry}
              onChange={handleCountryChange}
              className="px-3 py-2 bg-white-100 border border-gray-300 rounded-md focus:outline-none"
            >
              <option value="">Select Country</option>
              <option value="India">India</option>
              <option value="USA">USA</option>
              <option value="UK">UK</option>
              <option value="Canada">Canada</option>
              <option value="Australia">Australia</option>
              <option value="Germany">Germany</option>
              <option value="France">France</option>
              <option value="Italy">Italy</option>
              <option value="Japan">Japan</option>
              <option value="China">China</option>
              <option value="Brazil">Brazil</option>
              <option value="Russia">Russia</option>
            </select>


          <div className="hidden md:flex items-center space-x-6">
          {preferences.length > 0 ? (
  <>
    {preferences.map((category) => (
      <button
        key={category}
        onClick={() => {
          if (selectedCountry) {
            navigate(`/country/${selectedCountry}/category/${category}`);
          } else {
            navigate(`/category/${category}`);
          }
        }}
        className="text-gray-700 hover:text-gray-900"
      >
        {category}
      </button>
    ))}
    <button
      onClick={() => navigate("/foryou")}
      className="text-red-600 font-semibold hover:text-red-800"
    >
      For You
    </button>
  </>
) : (
  <>
    <span className="text-gray-400">No Preferences Set</span>
    <button
      onClick={() => navigate("/foryou")}
      className="text-red-600 font-semibold hover:text-red-800"
    >
      For You
    </button>
  </>
)}



            {/* Preference Button (Opens Modal) */}
            <div className="relative">
              <button
                onClick={() => setIsPreferencesMenuOpen(true)}
                className="text-gray-700 hover:text-gray-900 flex items-center"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>

            {/* Profile Button */}
            <div className="relative">
              <button
                className="flex items-center px-3 py-2 text-gray-700 hover:text-gray-900"
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              >
                <User className="h-6 w-6" />
                <div className="px-4 py-2 font-semibold">{username}</div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-md ring-1 ring-black ring-opacity-5 z-50">
                  <div className="py-1 text-gray-700">
                    <Link to="/profile" className="block px-4 py-2 hover:bg-gray-100">
                      Profile
                    </Link>
                    <Link to="/about" className="block px-4 py-2 hover:bg-gray-100">
                      About Us
                    </Link>
                    <Link to="/terms" className="block px-4 py-2 hover:bg-gray-100">
                      Terms of use
                    </Link>
                    <Link to="/privacy" className="block px-4 py-2 hover:bg-gray-100">
                      Privacy
                    </Link>
                    <Link to="/help" className="block px-4 py-2 hover:bg-gray-100">
                      Help
                    </Link>
                    <button
                      className="block w-full text-left px-4 py-2 text-red-500 hover:bg-gray-100"
                      onClick={handleLogout}
                    >
                      Logout
                    </button>
                  </div>
                </div>
              )}


      {/* Preferences Modal */}
      {isPreferencesMenuOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-xl w-96">
            <h2 className="text-lg font-semibold mb-4">
              {isEditMode ? "Remove Preferences" : "Add Preferences"}
            </h2>

            <div className="flex justify-between mb-4">
              <button
                onClick={() => setIsEditMode(false)}
                className={`px-3 py-2 ${!isEditMode ? "bg-red-500 text-white" : "bg-gray-300"} rounded`}
              >
                Add
              </button>
              <button
                onClick={() => setIsEditMode(true)}
                className={`px-3 py-2 ${isEditMode ? "bg-red-500 text-white" : "bg-gray-300"} rounded`}
              >
                Remove
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto">
              {isEditMode
                ? preferences.map((category) => (
                    <div key={category} className="flex justify-between p-2 border-b">
                      <span>{category}</span>
                      <button onClick={(e) => handleRemovePreference(category, e)} className="text-red-500">
                        ❌
                      </button>
                    </div>
                  ))
                : allPreferences
                    .filter((category) => !preferences.includes(category))
                    .map((category) => (
                      <div key={category} className="flex justify-between p-2 border-b">
                        <span>{category}</span>
                        <button onClick={(e) => handleAddPreference(category, e)} className="text-green-500">
                          ➕
                        </button>
                      </div>
                    ))}
            </div>

            <button
              onClick={() => setIsPreferencesMenuOpen(false)}
              className="mt-4 bg-gray-300 px-4 py-2 rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
    </nav>
  );
}
