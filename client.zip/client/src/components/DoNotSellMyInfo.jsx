import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";  // ✅ Main Navbar
import LoginNavbar from "../components/LoginNavbar";  // ✅ Navbar with login features
import Footer from "./footer";

export default function DoNotSellMyInfo() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState({ name: "", email: "", preferences: [] });
  const [userId, setUserId] = useState(localStorage.getItem("userId") || "");
  const [query, setQuery] = useState("news");

  useEffect(() => {
    // ✅ Check if user is logged in (by verifying token)
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token); // ✅ If token exists, user is logged in
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {isLoggedIn ? <LoginNavbar setUserId={setUserId} onSearch={setQuery} /> : <Navbar />}

      <div style={{ flex: 1, maxWidth: "800px", margin: "0 auto", padding: "20px" }}>
        <h1 style={{ textAlign: "center", fontSize: "30px", marginBottom: "20px" }}>
          Do Not Sell My Personal Information
        </h1>

        <p style={{ fontSize: "18px", textAlign: "justify" }}>
          At NewsVerse, we respect your privacy and provide you with control over your personal data.
          Under applicable laws, you have the right to opt out of the sale of your personal information.
        </p>

        <h2 style={{ fontSize: "22px", marginTop: "20px" }}>Your Rights</h2>
        <ul style={{ fontSize: "18px", marginLeft: "20px" }}>
          <li>✔ You can request that we do not sell your personal data.</li>
          <li>✔ You have the right to access the data we collect about you.</li>
          <li>✔ You can request data deletion in accordance with privacy laws.</li>
        </ul>

        

        <h2 style={{ fontSize: "22px", marginTop: "20px" }}>More Information</h2>
        <p style={{ fontSize: "18px" }}>
          For more details about how we handle your data, please visit our
          <a href="/privacy" style={{ color: "blue", textDecoration: "underline" }}> Privacy Policy</a>.
        </p>
      </div>

      <Footer />
    </div>
  );
}
